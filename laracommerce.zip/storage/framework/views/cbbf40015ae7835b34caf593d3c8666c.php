<?php
    $activeOptions = [
        ['label' => 'Active', 'value' => '1', 'selected' => true],
        ['label' => 'Non Active', 'value' => '0', 'selected' => false],
    ];
?>

<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div
        class="p-4 bg-white block sm:flex items-center justify-between border-b border-gray-200 lg:mt-1.5 dark:bg-gray-800 dark:border-gray-700">
        <div class="w-full mb-1">
            <?php if (isset($component)) { $__componentOriginal360d002b1b676b6f84d43220f22129e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal360d002b1b676b6f84d43220f22129e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $attributes = $__attributesOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__attributesOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $component = $__componentOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__componentOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>
            <h1 class="text-xl font-semibold text-gray-900 sm:text-2xl dark:text-white">Create new slider</h1>
        </div>
    </div>

    
    <div class="px-4 pt-6">
        <div
            class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm dark:border-gray-700 sm:p-6 dark:bg-gray-800 text-gray-900 dark:text-white">
            <form action="<?php echo e(route('admin.sliders.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-6 gap-6">
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'title']); ?>Title <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['id' => 'title','type' => 'text','name' => 'title','class' => 'mt-1','value' => ''.e(old('title')).'','placeholder' => 'E.g: New Arrivals','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'title','type' => 'text','name' => 'title','class' => 'mt-1','value' => ''.e(old('title')).'','placeholder' => 'E.g: New Arrivals','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'subtitle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'subtitle']); ?>Subtitle <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['id' => 'subtitle','type' => 'text','name' => 'subtitle','class' => 'mt-1','value' => ''.e(old('subtitle')).'','placeholder' => 'E.g: Men\'s Fashion','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'subtitle','type' => 'text','name' => 'subtitle','class' => 'mt-1','value' => ''.e(old('subtitle')).'','placeholder' => 'E.g: Men\'s Fashion','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'starting_price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'starting_price']); ?>Starting Price <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['id' => 'starting_price','type' => 'text','name' => 'starting_price','inputmode' => 'numeric','class' => 'mt-1','value' => ''.e(old('starting_price', 0)).'','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'starting_price','type' => 'text','name' => 'starting_price','inputmode' => 'numeric','class' => 'mt-1','value' => ''.e(old('starting_price', 0)).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['starting_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'url']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'url']); ?>Button Url <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['id' => 'url','type' => 'text','name' => 'url','class' => 'mt-1','value' => ''.e(old('url')).'','placeholder' => 'E.g: /products/hot-promo','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'url','type' => 'text','name' => 'url','class' => 'mt-1','value' => ''.e(old('url')).'','placeholder' => 'E.g: /products/hot-promo','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'position']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'position']); ?>Position <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['id' => 'position','type' => 'text','name' => 'position','class' => 'mt-1','value' => ''.e(old('position')).'','placeholder' => 'E.g: 1','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'position','type' => 'text','name' => 'position','class' => 'mt-1','value' => ''.e(old('position')).'','placeholder' => 'E.g: 1','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 sm:col-span-3">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'is_active']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'is_active']); ?>Status <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.select','data' => ['id' => 'is_active','name' => 'is_active','options' => $activeOptions,'class' => 'mt-1','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'is_active','name' => 'is_active','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeOptions),'class' => 'mt-1','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d)): ?>
<?php $attributes = $__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d; ?>
<?php unset($__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d)): ?>
<?php $component = $__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d; ?>
<?php unset($__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6">
                        <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'banner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'banner']); ?>Banner <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc19cf60a9600fd7945f97dda8651004a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc19cf60a9600fd7945f97dda8651004a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.file','data' => ['id' => 'banner','type' => 'file','name' => 'banner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'banner','type' => 'file','name' => 'banner']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc19cf60a9600fd7945f97dda8651004a)): ?>
<?php $attributes = $__attributesOriginalc19cf60a9600fd7945f97dda8651004a; ?>
<?php unset($__attributesOriginalc19cf60a9600fd7945f97dda8651004a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc19cf60a9600fd7945f97dda8651004a)): ?>
<?php $component = $__componentOriginalc19cf60a9600fd7945f97dda8651004a; ?>
<?php unset($__componentOriginalc19cf60a9600fd7945f97dda8651004a); ?>
<?php endif; ?>
                        <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-6 flex justify-end">
                        <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.index','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Create <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/admin/sliders/create.blade.php ENDPATH**/ ?>