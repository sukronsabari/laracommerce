<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['withIcon' => false, 'icon' => '', 'text' => '', 'href']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['withIcon' => false, 'icon' => '', 'text' => '', 'href']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!--[if BLOCK]><![endif]--><?php if(!$withIcon): ?>
    <a <?php echo e($attributes->merge(["class" => "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300
        font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none
        dark:focus:ring-blue-800"])); ?> href="<?php echo e($href); ?>"

    >
        <?php echo e($text ?? $slot); ?>

    </a>
<?php else: ?>
    <a <?php echo e($attributes->merge(["class" => "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-3 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"])); ?> href="<?php echo e($href); ?>">
        <span class="flex items-center justify-center w-5 h-5 me-2">
            <i class="<?php echo e($icon); ?>"></i>
        </span>
        <?php echo e($text ?? $slot); ?>

    </a>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/components/link/index.blade.php ENDPATH**/ ?>