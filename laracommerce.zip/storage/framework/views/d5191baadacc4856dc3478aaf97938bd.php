<div <?php echo count($attributes) ? $column->arrayToAttributes($attributes) : ''; ?>>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $button->getContents($row); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\vendor\rappasoft\laravel-livewire-tables\src/../resources/views/includes/columns/button-group.blade.php ENDPATH**/ ?>