<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['withIcon' => false, 'icon' => '', 'text' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['withIcon' => false, 'icon' => '', 'text' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!--[if BLOCK]><![endif]--><?php if(!$withIcon): ?>
    <button <?php echo e($attributes->merge(["class" => "text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"])); ?> type="button">
        <?php echo e($text ?? $slot); ?>

    </button>
<?php else: ?>
    <button <?php echo e($attributes->merge(["class" => "text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700 inline-flex text-center items-center"])); ?> type="button">
        <span class="flex items-center justify-center w-4 h-4 me-2">
            <i class="<?php echo e($icon); ?>"></i>
        </span>
        <?php echo e($text ?? $slot); ?>

    </button>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/components/button/light.blade.php ENDPATH**/ ?>