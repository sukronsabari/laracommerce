<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => '',
    'icon' => '',
    'text' => '',
    'href' => '#',
    'buttonTriggerIdentifier' => '',
    'collapseIdentifier' => '',
    'collapseItems' => [],
    'valueIndicator' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => '',
    'icon' => '',
    'text' => '',
    'href' => '#',
    'buttonTriggerIdentifier' => '',
    'collapseIdentifier' => '',
    'collapseItems' => [],
    'valueIndicator' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($type === 'single'): ?>
    <a href="<?php echo e($href); ?>"
        class="flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100 group dark:text-gray-200 dark:hover:bg-gray-700">
        <?php if($icon): ?>
            
            <i
                class="<?php echo e($icon); ?> block flex-shrink-0 text-2xl text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"></i>
        <?php endif; ?>

        <span class="ml-3" sidebar-toggle-item=""><?php echo e($text); ?></span>

        <?php if($valueIndicator): ?>
            <span
                class="inline-flex items-center justify-center w-3 h-3 p-3 ms-auto text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300"><?php echo e($valueIndicator); ?></span>
        <?php endif; ?>
    </a>
<?php elseif($type === 'collapse'): ?>
    <div>
        <button id="<?php echo e($buttonTriggerIdentifier); ?>" aria-controls="<?php echo e($collapseIdentifier); ?>"
            data-collapse-toggle="<?php echo e($collapseIdentifier); ?>" type="button"
            class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg group hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
            <?php if($icon): ?>
                
                <i
                    class="<?php echo e($icon); ?> block flex-shrink-0 text-2xl text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"></i>
            <?php endif; ?>
            <span class="flex-1 ml-3 text-left whitespace-nowrap" sidebar-toggle-item=""><?php echo e($text); ?></span>
            <svg sidebar-toggle-item="" class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
        <ul id="<?php echo e($collapseIdentifier); ?>" class="hidden py-2 space-y-2">
            <?php $__currentLoopData = $collapseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e($item['href']); ?>"
                        class="flex items-center p-2 text-base text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700">
                        <?php echo e($item['text']); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/components/sidebar/link.blade.php ENDPATH**/ ?>