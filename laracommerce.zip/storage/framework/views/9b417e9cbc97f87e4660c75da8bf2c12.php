<div
    class="fixed left-0 right-0 z-[9999999] bg-gray-900/50 dark:bg-gray-900/90 items-center justify-center hidden overflow-x-hidden overflow-y-auto top-0 md:inset-0 h-modal sm:h-full"
    x-cloak
    x-show="showAddSliderModal"
    x-bind:class="{ 'hidden': !showAddSliderModal, 'flex': showAddSliderModal }"
    x-transition:enter="transition ease-out duration-300"
    x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100"
    x-transition:leave="transition ease-in duration-200"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
>
    <div class="relative w-full h-full max-w-2xl px-4 pt-8 md:h-auto">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
            <!-- Modal header -->
            <div class="flex items-start justify-between p-5 border-b rounded-t dark:border-gray-700">
                <h3 class="text-xl font-semibold dark:text-white">
                    Add new slider
                </h3>
                <button
                    x-on:slider-created.window="showAddSliderModal = false"
                    x-on:click="showAddSliderModal = false"
                    type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-700 dark:hover:text-white">
                    <span class="flex items-center justify-center w-5 h-5">
                        <i class="ph ph-x text-xl"></i>
                    </span>
                </button>
            </div>
            <form wire:submit="save" novalidate>
                <!-- Modal body -->
                <?php echo csrf_field(); ?>
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-6 gap-6">
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'title']); ?>Title <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['wire:model' => 'title','id' => 'title','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: New Arrivals','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'title','id' => 'title','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: New Arrivals','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'subtitle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'subtitle']); ?>Subtitle <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['wire:model' => 'subtitle','id' => 'subtitle','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: Men\'s Fashion','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'subtitle','id' => 'subtitle','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: Men\'s Fashion','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'starting_price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'starting_price']); ?>Starting Price <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['wire:model' => 'starting_price','id' => 'starting_price','type' => 'text','inputmode' => 'numeric','class' => 'mt-1','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'starting_price','id' => 'starting_price','type' => 'text','inputmode' => 'numeric','class' => 'mt-1','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['starting_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'url']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'url']); ?>Button Url <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['wire:model' => 'url','id' => 'url','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: /products/hot-promo','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'url','id' => 'url','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: /products/hot-promo','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'position']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'position']); ?>Position <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald577c7dec18d40f4620a29a9f4a40645 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald577c7dec18d40f4620a29a9f4a40645 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.text','data' => ['wire:model' => 'position','id' => 'position','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: 1','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'position','id' => 'position','type' => 'text','class' => 'mt-1','placeholder' => 'E.g: 1','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $attributes = $__attributesOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__attributesOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald577c7dec18d40f4620a29a9f4a40645)): ?>
<?php $component = $__componentOriginald577c7dec18d40f4620a29a9f4a40645; ?>
<?php unset($__componentOriginald577c7dec18d40f4620a29a9f4a40645); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6 sm:col-span-3">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'is_active']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'is_active']); ?>Status <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.select','data' => ['wire:model' => 'is_active','id' => 'is_active','options' => $activeOptions,'class' => 'mt-1','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'is_active','id' => 'is_active','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeOptions),'class' => 'mt-1','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d)): ?>
<?php $attributes = $__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d; ?>
<?php unset($__attributesOriginalec0f377b60f1e2ad7b17ff3295f4376d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d)): ?>
<?php $component = $__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d; ?>
<?php unset($__componentOriginalec0f377b60f1e2ad7b17ff3295f4376d); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-span-6">
                            <?php if (isset($component)) { $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.label','data' => ['for' => 'banner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'banner']); ?>Banner <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $attributes = $__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__attributesOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08)): ?>
<?php $component = $__componentOriginal19cc3573ede92eaeb5dbc7c019225f08; ?>
<?php unset($__componentOriginal19cc3573ede92eaeb5dbc7c019225f08); ?>
<?php endif; ?>
                            <input wire:model="banner" id="banner" type="file" class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php if (isset($component)) { $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.error','data' => ['messages' => $message,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $attributes = $__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__attributesOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110)): ?>
<?php $component = $__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110; ?>
<?php unset($__componentOriginal4a767153f5c0ce7bdf9da2b62f71a110); ?>
<?php endif; ?>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="items-center p-6 border-t border-gray-200 rounded-b dark:border-gray-700">
                    <button
                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="submit">
                        Add Slider
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/livewire/sliders/add-slider-form.blade.php ENDPATH**/ ?>