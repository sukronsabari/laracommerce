<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 dark:bg-gray-800">
    <?php if (isset($component)) { $__componentOriginal185fefc612a42692c111eb84e666cc02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal185fefc612a42692c111eb84e666cc02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal185fefc612a42692c111eb84e666cc02)): ?>
<?php $attributes = $__attributesOriginal185fefc612a42692c111eb84e666cc02; ?>
<?php unset($__attributesOriginal185fefc612a42692c111eb84e666cc02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal185fefc612a42692c111eb84e666cc02)): ?>
<?php $component = $__componentOriginal185fefc612a42692c111eb84e666cc02; ?>
<?php unset($__componentOriginal185fefc612a42692c111eb84e666cc02); ?>
<?php endif; ?>
    <div class="flex pt-16 overflow-hidden bg-gray-50 dark:bg-gray-900">

        <?php if (isset($component)) { $__componentOriginalad37429a398962e91cd63eccf103f352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad37429a398962e91cd63eccf103f352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad37429a398962e91cd63eccf103f352)): ?>
<?php $attributes = $__attributesOriginalad37429a398962e91cd63eccf103f352; ?>
<?php unset($__attributesOriginalad37429a398962e91cd63eccf103f352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad37429a398962e91cd63eccf103f352)): ?>
<?php $component = $__componentOriginalad37429a398962e91cd63eccf103f352; ?>
<?php unset($__componentOriginalad37429a398962e91cd63eccf103f352); ?>
<?php endif; ?>
        <div class="fixed inset-0 z-10 hidden bg-gray-900/50 dark:bg-gray-900/90" id="sidebarBackdrop"></div>

        <main class="relative w-full h-full min-h-screen overflow-y-auto bg-gray-50 lg:ml-64 dark:bg-gray-900">
            <?php echo e($slot); ?>

        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Ngoding\Backend\Laravel\project\laracommerce\resources\views/layouts/admin.blade.php ENDPATH**/ ?>