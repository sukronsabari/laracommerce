<x-app-layout>
    HOME
</x-app-layout>
